import requests
import os
import json

from requests.exceptions import HTTPError

url = "https://w0w6pf6wy3.execute-api.us-west-2.amazonaws.com/test/creds"

headers = { "Content-Type": "application/json" }

params = dict(
    username='xyz',
    password='xyz'
)

def lambda_handler(event, context): 
    try:
        response = requests.get(url=url, params=params, headers=headers)
        print(f'Welcome to our demo API, here are the details of your request: {headers}')
        return(response.json())
        return(response.headers["Content-Type"])
        response.raise_for_status()
    except HTTPError as http_err:
        return(f'HTTP error occurred: {http_err}')
    except Exception as err:
        return(f'Other error occurred: {err}')
    else:
        return('Success!')