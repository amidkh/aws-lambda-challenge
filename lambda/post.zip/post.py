import requests
import os
import json

from requests.exceptions import HTTPError

url = "https://w0w6pf6wy3.execute-api.us-west-2.amazonaws.com/test/creds"

headers = { "Content-Type": "application/json" }

data = {"username":"xyz", "password":"xyz"}

def lambda_handler(event, context): 
    try:
        response = requests.post(url, data=json.dumps(data), headers=headers).json()
        return(response)
        response.raise_for_status()
    except HTTPError as http_err:
        print(f'HTTP error occurred: {http_err}')
    except Exception as err:
        print(f'Other error occurred: {err}')
    else:
        print('Success!')